from setuptools import setup

setup(

  name = 'Segunda_pre-entrega_Bruzzesi',
  version = '1.2',
  author = 'Lucas Bruzzesi',

  packages = ['segundape'],

)