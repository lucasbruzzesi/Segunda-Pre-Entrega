from setuptools import setup

setup(

  name = 'Segunda_pre-entrega_Bruzzesi',
  version = '1.4',
  author = 'Lucas Bruzzesi',

  packages = ['segundape'],

)